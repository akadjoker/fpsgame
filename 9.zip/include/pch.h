#define _CRT_SECURE_NO_WARNINGS
#include <stddef.h>
#include <cstddef> // for std::nullptr_t
#include <cstdio>

#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cfloat>
#include <cassert>
#include <time.h>

#include <raylib.h>
#include <raymath.h>
#include <rlgl.h>
#include <map>
#include <utility>
#include <vector>
#include <string>
#include <functional>
#include <random>


#include <cmath>